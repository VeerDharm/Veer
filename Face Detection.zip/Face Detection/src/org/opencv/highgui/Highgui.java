/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.opencv.highgui;

import org.opencv.core.Mat;
import org.opencv.core.MatOfByte;

/**
 *
 * @author pc
 */
public class Highgui {

    public static void imencode(String bmp, Mat frame, MatOfByte mem) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
